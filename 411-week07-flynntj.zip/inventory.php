<html>
<head>
<title>Inventory</title>
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>
<body>
<!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.min.js"></script>
	  <script>
    $(document).ready(function(){
        setInterval(function() {
            $("#latestData").load("inventory.php #latestData");
        }, 1000);
    });

</script>
  <div class="navbar-fixed">
  <nav>
    <div class="nav-wrapper blue">
      <a href="index.php" class="brand-logo">Inventory</a>
    </div>
  </nav>
  </div>
  <body>
    

    
  <div class="container"><br/><br/>
  <div id = "latestData">
<?php

$connection = mysqli_connect('localhost', 'root', '', 'order_processing');

$sql = "SELECT * from INVENTORY";
$result = $connection->query($sql);		

echo('<table class = "centered"><thead><th>InventoryID</th><th>Name</th><th>Description</th><th>Cost</th><th>Price</th><th>Quantity</th></thead>');
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["inventoryId"] . "</td><td> " . $row["name"]. "</td><td>" . $row["description"]. "</td><td>" .$row["cost"]."</td><td>". $row["price"]. "</td><td>" .$row["units"]."</td></tr>";
    }
} else {
    echo "0 results";
}
echo('</table>');
mysqli_close($connection);
?>
</div>
</div>
</body>
</html>