package orderprocessing;

/**
 *
 * @author sab5964 and tjf5285
 */
public enum TransactionType {
    ORDER, ADJUSTMENT, EXCHANGE, RETURN, SALE
}
